from . import AWSObject, Tags
from .validators import boolean


class FileSystem(AWSObject):
    resource_type = "AWS::EFS::FileSystem"

    props = {
        'Encrypted': (boolean, False),
        'FileSystemTags': (Tags, False),
        'KmsKeyId': (str, False),
        'PerformanceMode': (str, False),
    }


class MountTarget(AWSObject):
    resource_type = "AWS::EFS::MountTarget"

    props = {
        'FileSystemId': (str, True),
        'IpAddress': (str, False),
        'SecurityGroups': ([str], True),
        'SubnetId': (str, True),
    }
